import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'API Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const MyHomePage(title: 'JSONPlaceholder Posts'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List posts = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    fetchPosts();
  }

  Future<void> fetchPosts() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      // Sending a GET request (task2)
      final url = Uri.parse('https://jsonplaceholder.typicode.com/posts');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        // Decoding JSON into Dart object and printing the first post's title (Task3)
        final data = jsonDecode(response.body);
        print("First post title: ${data[0]['title']}");

        setState(() {
          posts = data;
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = "Failed to load posts. Code: ${response.statusCode}";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Error: $e";
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Center(
        child: isLoading
            //Task5 showing a CircularProgressIndicator while data is loading and hide it when complete.
            ? const CircularProgressIndicator()
            : errorMessage != null
                //Task6 if the request fails, display an error message and a “Retry” button.
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(errorMessage!),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: fetchPosts,
                        child: const Text("Retry"),
                      ),
                    ],
                  )
                // Task4 displaying all post tittles
                : ListView.builder(
                    itemCount: posts.length,
                    itemBuilder: (context, index) {
                      final post = posts[index];
                      return ListTile(
                        title: Text(posts[index]['title']),
                        onTap: () {
                          // task7
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailsScreen(post: post),
                            ),
                          );
                        },
                      );
                    },
                  ),
      ),
      // floatingActionButton: FloatingActionButton( // this function was used for previous tasks
      //   onPressed: () {
      //     Navigator.push(
      //       context,
      //       MaterialPageRoute(builder: (context) => const AddPostScreen()),
      //     );
      //   },
      //   child: const Icon(Icons.add),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CurrencyScreen()),
          );
        },
        child: const Icon(Icons.monetization_on),
      ),
    );
  }
}

//Task 7
class DetailsScreen extends StatelessWidget {
  final Map post;
  const DetailsScreen({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Post Details"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              post['title'],
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(post['body']),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                // task8
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Back"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//Task 9
class AddPostScreen extends StatefulWidget {
  const AddPostScreen({super.key});

  @override
  State<AddPostScreen> createState() => _AddPostScreenState();
}

class _AddPostScreenState extends State<AddPostScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController bodyController = TextEditingController();

  bool isLoading = false;

  Future<void> submitPost() async {
    final title = titleController.text.trim();
    final body = bodyController.text.trim();

    if (title.isEmpty || body.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("FILL THE FIELDS!")),
      );
      return;
    }

    setState(() => isLoading = true);

    try {
      final url = Uri.parse('https://reqres.in/api/posts');
      final response = await http.post(
        url,
        body: {'title': title, 'body': body},
      );

      print("Response status: ${response.statusCode}");
      print("Response body: ${response.body}");

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Post submitted successfully")),
      );

      Navigator.pop(context);
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add New Post"),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: "Title"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: bodyController,
              decoration: const InputDecoration(labelText: "Body"),
              maxLines: 3,
            ),
            const SizedBox(height: 20),
            isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: submitPost,
                    child: const Text(
                      "Submit",
                    ),
                  ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Back"),
            ),
          ],
        ),
      ),
    );
  }
}

//Part E
class CurrencyScreen extends StatefulWidget {
  const CurrencyScreen({super.key});

  @override
  State<CurrencyScreen> createState() => _CurrencyScreenState();
}

class _CurrencyScreenState extends State<CurrencyScreen> {
  final TextEditingController dateController = TextEditingController();
  final TextEditingController codeController = TextEditingController();

  bool isLoading = false;
  List currencies = [];
  String? errorMessage;

  Future<void> fetchCurrency() async {
    final date = dateController.text.trim();
    final code = codeController.text.trim().toUpperCase();

    String url = "https://cbu.uz/ru/arkhiv-kursov-valyut/json/";
    if (date.isNotEmpty && code.isNotEmpty) {
      url += "$code/$date/";
    } else if (date.isNotEmpty && code.isEmpty) {
      url += "all/$date/";
    }

    setState(() {
      isLoading = true;
      errorMessage = null;
      currencies.clear();
    });

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          currencies = data;
          isLoading = false;
        });
        print("Fetched ${currencies.length} currencies from $url");
      } else {
        setState(() {
          errorMessage = "Failed (${response.statusCode})";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Error: $e";
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Currency Rates (UZS)"),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: dateController,
              decoration: const InputDecoration(
                labelText: "Date (YYYY-MM-DD)",
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: codeController,
              decoration: const InputDecoration(
                labelText: "Currency Code (USD, RUB, or all)",
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: fetchCurrency,
              child: const Text("Fetch Rates"),
            ),
            const SizedBox(height: 20),
            if (isLoading)
              const CircularProgressIndicator()
            else if (errorMessage != null)
              Text(errorMessage!)
            else
              Expanded(
                child: ListView.builder(
                  itemCount: currencies.length,
                  itemBuilder: (context, index) {
                    final c = currencies[index];
                    return Card(
                      child: ListTile(
                        title: Text("${c['CcyNm_UZ']}  (${c['Ccy']})"),
                        subtitle: Text("Rate: ${c['Rate']} UZS"),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Back"),
            ),
          ],
        ),
      ),
    );
  }
}
