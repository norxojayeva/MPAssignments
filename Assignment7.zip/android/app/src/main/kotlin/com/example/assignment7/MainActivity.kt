package com.example.assignment7

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
